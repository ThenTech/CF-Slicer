﻿namespace Slicer.slyce.Constructs
{
    public enum AdhesionType
    {
        NONE, BRIM, SKIRT
    }
}
