﻿namespace Slicer.slyce.Constructs
{
    public enum ConnectionType
    {
        NOT, FIRST, LAST, FIRSTREVERSED, LASTREVERSED
    }
}
