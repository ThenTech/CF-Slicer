namespace Slicer.slyce.GCode.Commands
{
    [Command(CommandType.M, 107)]
    public class FanOff : GCodeBase
    {
    }
}