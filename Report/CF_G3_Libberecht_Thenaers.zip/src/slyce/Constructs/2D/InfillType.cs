﻿namespace Slicer.slyce.Constructs
{
    public enum InfillType
    {
        NONE, SINGLE, SINGLE_ROTATED, RECTANGLE, SQUARE, DIAMOND, TRIANGLES, TRI_HEXAGONS, ZIGZAG
    }
}
