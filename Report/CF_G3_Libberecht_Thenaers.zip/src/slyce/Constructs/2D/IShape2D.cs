﻿namespace Slicer.slyce.Constructs
{
    public interface IShape2D
    {
    }
}
