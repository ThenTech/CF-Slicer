namespace Slicer.slyce.GCode.Commands
{
    [Command(CommandType.G, 90)]
    public class SetAbsolutePositioning : GCodeBase
    {
    }
}