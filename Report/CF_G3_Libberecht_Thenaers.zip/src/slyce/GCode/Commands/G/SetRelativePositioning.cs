namespace Slicer.slyce.GCode.Commands
{
    [Command(CommandType.G, 91)]
    public class SetRelativePositioning : GCodeBase
    {
    }
}