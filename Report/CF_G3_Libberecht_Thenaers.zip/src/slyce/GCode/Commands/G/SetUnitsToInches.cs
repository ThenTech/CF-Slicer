namespace Slicer.slyce.GCode.Commands
{
    [Command(CommandType.G, 20)]
    public class SetUnitsToInches : GCodeBase
    {
    }
}