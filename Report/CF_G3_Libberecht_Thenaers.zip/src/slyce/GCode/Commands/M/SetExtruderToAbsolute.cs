namespace Slicer.slyce.GCode.Commands
{
    [Command(CommandType.M, 82)]
    public class SetExtruderToAbsolute : GCodeBase
    {
    }
}